# Agent Notes

- Ignore the `_bmad` and `_bmad-output` directories when scanning the repository.
