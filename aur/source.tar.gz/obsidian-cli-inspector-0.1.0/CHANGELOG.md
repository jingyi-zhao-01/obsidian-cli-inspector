# Changelog

## [0.1.0](https://github.com/jingyi-zhao-01/obsidian-cli-inspector/compare/v0.0.7...v0.1.0) (2026-02-28)


### Features

* add diagnose-orphans and diagnose-broken-links commands ([#17](https://github.com/jingyi-zhao-01/obsidian-cli-inspector/issues/17)) ([05743bd](https://github.com/jingyi-zhao-01/obsidian-cli-inspector/commit/05743bd01dbc30387d15ae4fac73852800019691))


### Bug Fixes

* add release token ([6e8ef77](https://github.com/jingyi-zhao-01/obsidian-cli-inspector/commit/6e8ef7701e032f9d3b5d51053fee375686c69d92))
